# adhirageraassignment

A new Flutter project.

>This Flutter app was made by Adhira Gera, 18BCY10006 for Yellow Class Qualifier 1.
> Incase of password: 123456
>Thank You.