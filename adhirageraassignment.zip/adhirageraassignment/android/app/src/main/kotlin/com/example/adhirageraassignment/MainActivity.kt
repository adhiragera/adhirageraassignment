package com.example.adhirageraassignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
